<?php

/*
  Example:
  
  $product_data['product_id'] = $product['product_id']; //inline code
  $product_data['price'] = str_replace('$','',$product_data['price']); //inline code
  
  ..etc
*/

?>